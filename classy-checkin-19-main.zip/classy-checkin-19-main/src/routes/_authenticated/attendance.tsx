import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Check, X, Clock, Save } from "lucide-react";
import { format } from "date-fns";
import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/attendance")({
  head: () => ({ meta: [{ title: "Attendance — AttendEase" }] }),
  component: AttendancePage,
});

type Status = "present" | "absent" | "late";

function AttendancePage() {
  const qc = useQueryClient();
  const { roles, user } = useCurrentUser();
  const canMark = roles.includes("admin") || roles.includes("teacher");
  const [classId, setClassId] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [marks, setMarks] = useState<Record<string, Status>>({});

  const classes = useQuery({
    queryKey: ["att-classes"],
    queryFn: async () => (await supabase.from("classes").select("*").order("name")).data ?? [],
  });

  const subjects = useQuery({
    queryKey: ["att-subjects", classId],
    queryFn: async () => {
      if (!classId) return [];
      return (await supabase.from("class_subjects").select("*").eq("class_id", classId)).data ?? [];
    },
    enabled: !!classId,
  });

  const students = useQuery({
    queryKey: ["att-students", classId],
    queryFn: async () => {
      if (!classId) return [];
      return (await supabase.from("students").select("*").eq("class_id", classId).order("roll_number")).data ?? [];
    },
    enabled: !!classId,
  });

  const existing = useQuery({
    queryKey: ["att-existing", classId, subjectId, date],
    queryFn: async () => {
      if (!classId || !subjectId) return [];
      return (await supabase.from("attendance").select("*")
        .eq("class_id", classId).eq("subject_id", subjectId).eq("date", date)).data ?? [];
    },
    enabled: !!classId && !!subjectId,
  });

  // student view
  const studentRecord = useQuery({
    queryKey: ["my-student", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase.from("students").select("*").eq("user_id", user.id).maybeSingle();
      return data;
    },
    enabled: !!user && !canMark,
  });

  const myAttendance = useQuery({
    queryKey: ["my-attendance", studentRecord.data?.id],
    queryFn: async () => {
      if (!studentRecord.data) return [];
      return (await supabase.from("attendance")
        .select("*, class_subjects(subject_name)")
        .eq("student_id", studentRecord.data.id)
        .order("date", { ascending: false })
        .limit(50)).data ?? [];
    },
    enabled: !!studentRecord.data,
  });

  useEffect(() => {
    const next: Record<string, Status> = {};
    (students.data ?? []).forEach((s) => { next[s.id] = "present"; });
    (existing.data ?? []).forEach((a) => { next[a.student_id] = a.status as Status; });
    setMarks(next);
  }, [students.data, existing.data]);

  const save = async () => {
    if (!classId || !subjectId) return toast.error("Pick class and subject");
    const rows = Object.entries(marks).map(([student_id, status]) => ({
      student_id, class_id: classId, subject_id: subjectId, date, status,
    }));
    const { error } = await supabase.from("attendance").upsert(rows, {
      onConflict: "student_id,subject_id,date",
    });
    if (error) return toast.error(error.message);
    toast.success(`Saved attendance for ${rows.length} students`);
    qc.invalidateQueries({ queryKey: ["att-existing"] });
    qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
    qc.invalidateQueries({ queryKey: ["attendance-chart"] });
  };

  if (!canMark) {
    return (
      <AppShell title="My Attendance">
        <Card className="p-6">
          <h2 className="font-semibold mb-4">Recent attendance</h2>
          {!studentRecord.data && (
            <p className="text-muted-foreground">No student profile linked to your account yet.</p>
          )}
          <div className="space-y-2">
            {(myAttendance.data ?? []).map((a) => (
              <div key={a.id} className="flex items-center justify-between p-3 rounded border">
                <div>
                  <div className="font-medium">{a.class_subjects?.subject_name ?? "—"}</div>
                  <div className="text-xs text-muted-foreground">{a.date}</div>
                </div>
                <StatusBadge status={a.status as Status} />
              </div>
            ))}
            {(myAttendance.data ?? []).length === 0 && studentRecord.data && (
              <p className="text-muted-foreground text-sm">No attendance records yet.</p>
            )}
          </div>
        </Card>
      </AppShell>
    );
  }

  return (
    <AppShell title="Mark Attendance">
      <Card className="p-6 mb-6">
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <Label>Class</Label>
            <Select value={classId} onValueChange={(v) => { setClassId(v); setSubjectId(""); }}>
              <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
              <SelectContent>
                {(classes.data ?? []).map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name} - {c.section}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Subject</Label>
            <Select value={subjectId} onValueChange={setSubjectId} disabled={!classId}>
              <SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
              <SelectContent>
                {(subjects.data ?? []).map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.subject_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Date</Label>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
        </div>
      </Card>

      {classId && subjectId && (
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">{(students.data ?? []).length} students</h2>
            <Button onClick={save}><Save className="w-4 h-4 mr-2" /> Save Attendance</Button>
          </div>
          <div className="space-y-2">
            {(students.data ?? []).map((s) => (
              <div key={s.id} className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50">
                <div>
                  <div className="font-medium">{s.name}</div>
                  <div className="text-xs text-muted-foreground font-mono">{s.roll_number}</div>
                </div>
                <div className="flex gap-1">
                  {(["present", "late", "absent"] as Status[]).map((st) => (
                    <button
                      key={st}
                      onClick={() => setMarks({ ...marks, [s.id]: st })}
                      className={cn(
                        "px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1",
                        marks[s.id] === st
                          ? st === "present" ? "bg-success text-success-foreground"
                            : st === "late" ? "bg-warning text-warning-foreground"
                            : "bg-destructive text-destructive-foreground"
                          : "bg-secondary text-secondary-foreground hover:bg-secondary/70",
                      )}
                    >
                      {st === "present" && <Check className="w-3 h-3" />}
                      {st === "late" && <Clock className="w-3 h-3" />}
                      {st === "absent" && <X className="w-3 h-3" />}
                      {st.charAt(0).toUpperCase() + st.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {(students.data ?? []).length === 0 && (
              <p className="text-center text-muted-foreground py-8">No students in this class.</p>
            )}
          </div>
        </Card>
      )}
    </AppShell>
  );
}

function StatusBadge({ status }: { status: Status }) {
  const map = {
    present: "bg-success text-success-foreground",
    late: "bg-warning text-warning-foreground",
    absent: "bg-destructive text-destructive-foreground",
  };
  return (
    <span className={cn("px-2.5 py-1 rounded-full text-xs font-medium", map[status])}>
      {status}
    </span>
  );
}
