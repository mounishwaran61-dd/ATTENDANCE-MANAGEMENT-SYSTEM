import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { GraduationCap, Users, BookOpen, ClipboardCheck, TrendingUp } from "lucide-react";
import { format, subDays } from "date-fns";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid,
} from "recharts";
import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — AttendEase" }] }),
  component: Dashboard,
});

function Dashboard() {
  const stats = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const today = format(new Date(), "yyyy-MM-dd");
      const [students, teachers, classes, todayAtt] = await Promise.all([
        supabase.from("students").select("*", { count: "exact", head: true }),
        supabase.from("teachers").select("*", { count: "exact", head: true }),
        supabase.from("classes").select("*", { count: "exact", head: true }),
        supabase.from("attendance").select("status").eq("date", today),
      ]);
      const total = todayAtt.data?.length ?? 0;
      const present = todayAtt.data?.filter((a) => a.status === "present").length ?? 0;
      const pct = total > 0 ? Math.round((present / total) * 100) : 0;
      return {
        students: students.count ?? 0,
        teachers: teachers.count ?? 0,
        classes: classes.count ?? 0,
        attendancePct: pct,
        marked: total,
      };
    },
  });

  const chart = useQuery({
    queryKey: ["attendance-chart"],
    queryFn: async () => {
      const start = format(subDays(new Date(), 6), "yyyy-MM-dd");
      const { data } = await supabase
        .from("attendance")
        .select("date, status")
        .gte("date", start);
      const days: Record<string, { date: string; present: number; absent: number; late: number }> = {};
      for (let i = 6; i >= 0; i--) {
        const d = format(subDays(new Date(), i), "yyyy-MM-dd");
        days[d] = { date: format(subDays(new Date(), i), "EEE"), present: 0, absent: 0, late: 0 };
      }
      (data ?? []).forEach((r) => {
        const k = days[r.date];
        if (k) k[r.status as "present" | "absent" | "late"]++;
      });
      return Object.values(days);
    },
  });

  const cards = [
    { label: "Students", value: stats.data?.students ?? 0, icon: GraduationCap, color: "text-primary" },
    { label: "Teachers", value: stats.data?.teachers ?? 0, icon: Users, color: "text-accent" },
    { label: "Classes", value: stats.data?.classes ?? 0, icon: BookOpen, color: "text-chart-5" },
    { label: "Today's Attendance", value: `${stats.data?.attendancePct ?? 0}%`, icon: TrendingUp, color: "text-success", sub: `${stats.data?.marked ?? 0} marked` },
  ];

  return (
    <AppShell title="Dashboard">
      <div className="space-y-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {cards.map((c) => (
            <Card key={c.label} className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
                    {c.label}
                  </div>
                  <div className="text-3xl font-bold mt-2">{c.value}</div>
                  {c.sub && (
                    <div className="text-xs text-muted-foreground mt-1">{c.sub}</div>
                  )}
                </div>
                <c.icon className={`w-8 h-8 ${c.color} opacity-80`} />
              </div>
            </Card>
          ))}
        </div>

        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <ClipboardCheck className="w-5 h-5 text-primary" />
            <h2 className="font-semibold">Attendance — Last 7 days</h2>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart.data ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="present" stackId="a" fill="var(--chart-2)" radius={[0, 0, 0, 0]} />
                <Bar dataKey="late" stackId="a" fill="var(--chart-3)" radius={[0, 0, 0, 0]} />
                <Bar dataKey="absent" stackId="a" fill="var(--chart-4)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
