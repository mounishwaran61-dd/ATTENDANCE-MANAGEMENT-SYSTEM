import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { format, startOfMonth, endOfMonth } from "date-fns";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend,
} from "recharts";
import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({ meta: [{ title: "Reports — AttendEase" }] }),
  component: ReportsPage,
});

function ReportsPage() {
  const [classId, setClassId] = useState("all");
  const [month, setMonth] = useState(format(new Date(), "yyyy-MM"));

  const classes = useQuery({
    queryKey: ["rep-classes"],
    queryFn: async () => (await supabase.from("classes").select("*")).data ?? [],
  });

  const att = useQuery({
    queryKey: ["report-att", classId, month],
    queryFn: async () => {
      const start = format(startOfMonth(new Date(`${month}-01`)), "yyyy-MM-dd");
      const end = format(endOfMonth(new Date(`${month}-01`)), "yyyy-MM-dd");
      let q = supabase.from("attendance")
        .select("*, students(name, roll_number, class_id)")
        .gte("date", start).lte("date", end);
      if (classId !== "all") q = q.eq("class_id", classId);
      return (await q).data ?? [];
    },
  });

  const summary = useMemo(() => {
    const data = att.data ?? [];
    const total = data.length;
    const present = data.filter((r) => r.status === "present").length;
    const late = data.filter((r) => r.status === "late").length;
    const absent = data.filter((r) => r.status === "absent").length;

    const perStudent: Record<string, { name: string; roll: string; p: number; l: number; a: number }> = {};
    data.forEach((r) => {
      const s = r.students;
      if (!s) return;
      const key = s.roll_number;
      if (!perStudent[key]) perStudent[key] = { name: s.name, roll: s.roll_number, p: 0, l: 0, a: 0 };
      if (r.status === "present") perStudent[key].p++;
      if (r.status === "late") perStudent[key].l++;
      if (r.status === "absent") perStudent[key].a++;
    });

    return {
      total, present, late, absent,
      pct: total ? Math.round(((present + late) / total) * 100) : 0,
      pieData: [
        { name: "Present", value: present, color: "var(--chart-2)" },
        { name: "Late", value: late, color: "var(--chart-3)" },
        { name: "Absent", value: absent, color: "var(--chart-4)" },
      ],
      perStudent: Object.values(perStudent).sort((a, b) => a.roll.localeCompare(b.roll)),
    };
  }, [att.data]);

  return (
    <AppShell title="Attendance Reports">
      <Card className="p-4 mb-6">
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <Label>Class</Label>
            <Select value={classId} onValueChange={setClassId}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {(classes.data ?? []).map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name} - {c.section}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Month</Label>
            <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
          </div>
        </div>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <Card className="p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Total Records</div>
          <div className="text-3xl font-bold mt-2">{summary.total}</div>
        </Card>
        <Card className="p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Attendance Rate</div>
          <div className="text-3xl font-bold mt-2 text-success">{summary.pct}%</div>
        </Card>
        <Card className="p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Absences</div>
          <div className="text-3xl font-bold mt-2 text-destructive">{summary.absent}</div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-6">
          <h2 className="font-semibold mb-4">Distribution</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={summary.pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                  {summary.pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="font-semibold mb-4">Per Student</h2>
          <div className="border rounded-lg overflow-hidden max-h-64 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="text-right">P / L / A</TableHead>
                  <TableHead className="text-right">%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {summary.perStudent.length === 0 && (
                  <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6">No data</TableCell></TableRow>
                )}
                {summary.perStudent.map((s) => {
                  const tot = s.p + s.l + s.a;
                  const pct = tot ? Math.round(((s.p + s.l) / tot) * 100) : 0;
                  return (
                    <TableRow key={s.roll}>
                      <TableCell className="font-mono text-xs">{s.roll}</TableCell>
                      <TableCell className="font-medium text-sm">{s.name}</TableCell>
                      <TableCell className="text-right text-xs">
                        <span className="text-success">{s.p}</span> /{" "}
                        <span className="text-warning">{s.l}</span> /{" "}
                        <span className="text-destructive">{s.a}</span>
                      </TableCell>
                      <TableCell className="text-right font-medium">{pct}%</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
