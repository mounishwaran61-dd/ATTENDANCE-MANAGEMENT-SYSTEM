import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Trash2, BookOpen } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/classes")({
  head: () => ({ meta: [{ title: "Classes — AttendEase" }] }),
  component: ClassesPage,
});

function ClassesPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [subjOpen, setSubjOpen] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", section: "A", academic_year: `${new Date().getFullYear()}` });
  const [subjForm, setSubjForm] = useState({ subject_name: "", teacher_id: "" });

  const classes = useQuery({
    queryKey: ["classes-full"],
    queryFn: async () => {
      const { data } = await supabase
        .from("classes")
        .select("*, class_subjects(id, subject_name, teacher_id, teachers(name))")
        .order("name");
      return data ?? [];
    },
  });

  const teachers = useQuery({
    queryKey: ["teachers-list"],
    queryFn: async () => (await supabase.from("teachers").select("id, name")).data ?? [],
  });

  const addClass = async () => {
    if (!form.name) return toast.error("Class name is required");
    const { error } = await supabase.from("classes").insert(form);
    if (error) return toast.error(error.message);
    toast.success("Class added");
    setOpen(false);
    setForm({ name: "", section: "A", academic_year: `${new Date().getFullYear()}` });
    qc.invalidateQueries({ queryKey: ["classes-full"] });
  };

  const delClass = async (id: string) => {
    if (!confirm("Delete class and all its subjects?")) return;
    const { error } = await supabase.from("classes").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["classes-full"] });
  };

  const addSubject = async () => {
    if (!subjOpen || !subjForm.subject_name) return;
    const { error } = await supabase.from("class_subjects").insert({
      class_id: subjOpen,
      subject_name: subjForm.subject_name,
      teacher_id: subjForm.teacher_id || null,
    });
    if (error) return toast.error(error.message);
    toast.success("Subject added");
    setSubjForm({ subject_name: "", teacher_id: "" });
    setSubjOpen(null);
    qc.invalidateQueries({ queryKey: ["classes-full"] });
  };

  const delSubject = async (id: string) => {
    const { error } = await supabase.from("class_subjects").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["classes-full"] });
  };

  return (
    <AppShell title="Classes & Subjects">
      <div className="flex justify-end mb-4">
        <Button onClick={() => setOpen(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Class
        </Button>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(classes.data ?? []).length === 0 && (
          <Card className="p-8 text-center text-muted-foreground col-span-full">
            No classes yet. Add your first class to get started.
          </Card>
        )}
        {(classes.data ?? []).map((c) => (
          <Card key={c.id} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-primary" />
                  <h3 className="font-semibold">{c.name}</h3>
                  <Badge variant="secondary">Sec {c.section}</Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-1">AY {c.academic_year}</div>
              </div>
              <Button size="icon" variant="ghost" onClick={() => delClass(c.id)}>
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2">
              Subjects
            </div>
            <div className="space-y-1 mb-3">
              {(c.class_subjects ?? []).length === 0 && (
                <div className="text-sm text-muted-foreground italic">No subjects</div>
              )}
              {(c.class_subjects ?? []).map((s) => (
                <div key={s.id} className="flex items-center justify-between text-sm p-2 rounded bg-secondary">
                  <div>
                    <div className="font-medium">{s.subject_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {s.teachers?.name ?? "Unassigned"}
                    </div>
                  </div>
                  <Button size="icon" variant="ghost" onClick={() => delSubject(s.id)}>
                    <Trash2 className="w-3.5 h-3.5 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
            <Button size="sm" variant="outline" className="w-full" onClick={() => setSubjOpen(c.id)}>
              <Plus className="w-3.5 h-3.5 mr-1" /> Add Subject
            </Button>
          </Card>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Class</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><Label>Class Name</Label><Input placeholder="e.g. Grade 10" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label>Section</Label><Input value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} /></div>
            <div><Label>Academic Year</Label><Input value={form.academic_year} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={addClass}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!subjOpen} onOpenChange={(o) => !o && setSubjOpen(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Subject</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Subject Name</Label><Input value={subjForm.subject_name} onChange={(e) => setSubjForm({ ...subjForm, subject_name: e.target.value })} /></div>
            <div>
              <Label>Teacher</Label>
              <Select value={subjForm.teacher_id} onValueChange={(v) => setSubjForm({ ...subjForm, teacher_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select teacher" /></SelectTrigger>
                <SelectContent>
                  {(teachers.data ?? []).map((t) => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setSubjOpen(null)}>Cancel</Button>
            <Button onClick={addSubject}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
