# Attendance Management System — Implementation Plan

## Overview
Build a complete attendance management web application with role-based access control, covering all 6 requested modules: User Management, Student Management, Teacher Management, Attendance Management, Reports, and Dashboard.

## Tech Stack
- Frontend: React 19 + TanStack Router/Start + Tailwind CSS v4 + shadcn/ui
- Backend: TanStack Server Functions + Lovable Cloud (Supabase)
- Auth: Lovable Cloud managed email/password + Google OAuth
- Database: PostgreSQL via Lovable Cloud
- Charts: Recharts (already installed)

## Design Direction
Clean academic style — navy/blue primary palette on white backgrounds. Professional, trustworthy, easy to navigate. Use semantic design tokens in `src/styles.css`.

---

## Phase 1: Database Schema

Create a single migration with:

1. **Enum: `app_role`** — `admin`, `teacher`, `student`
2. **Table: `classes`** — id, name, section, academic_year, created_at
3. **Table: `students`** — id, user_id (FK auth.users), roll_number, name, email, phone, class_id, date_of_birth, gender, address, created_at
4. **Table: `teachers`** — id, user_id (FK auth.users), employee_id, name, email, phone, department, qualification, created_at
5. **Table: `class_subjects`** — id, class_id, teacher_id, subject_name, created_at
6. **Table: `attendance`** — id, student_id, class_id, subject_id, teacher_id, date, status (present/absent/late), created_at
7. **Table: `user_roles`** — id, user_id (FK auth.users), role

All tables need GRANTs + RLS policies. Add `has_role()` security definer function.

Also create a trigger that auto-creates a profile record on signup, and seed the admin account (`admin`/`admin123`) via a server function.

---

## Phase 2: Auth & Route Structure

### Routes
| URL | Purpose | Auth |
|---|---|---|
| `/` | Public landing / info page | Public |
| `/auth` | Login / register | Public |
| `/_authenticated/dashboard` | Dashboard with stats | Protected |
| `/_authenticated/students` | Student CRUD | Admin/Teacher |
| `/_authenticated/teachers` | Teacher CRUD | Admin |
| `/_authenticated/classes` | Class & subject CRUD | Admin |
| `/_authenticated/attendance` | Mark & view attendance | Admin/Teacher |
| `/_authenticated/reports` | Attendance reports | Admin/Teacher |
| `/_authenticated/profile` | User profile | Protected |

### Auth Flow
- Use Lovable Cloud `supabase.auth.signInWithPassword()` for email/password
- Auto-seed admin on first app load (server function checks if admin exists, creates if not)
- Role-gate routes with `has_role()` checks in middleware and UI

---

## Phase 3: Design System

Update `src/styles.css` with academic palette:
- Primary: deep navy blue (`oklch(0.5 0.15 250)`)
- Secondary: soft sky blue
- Accent: warm amber for highlights/CTAs
- Success/error states for attendance marking

Add custom button variants (hero, outline-primary) and card styles in the design system. No ad-hoc colors in components.

---

## Phase 4: Core Components

1. **Layout / Shell**
   - Sidebar navigation with role-aware links
   - Top bar with user avatar + logout
   - Breadcrumb or section title

2. **Reusable Components**
   - Data tables (students, teachers, classes)
   - Forms with validation (zod + react-hook-form)
   - Date picker for attendance
   - Stat cards for dashboard
   - Attendance status badges (Present/Absent/Late)

3. **Dashboard**
   - Summary cards: total students, teachers, classes, today's attendance %
   - Recent attendance chart (last 7 days)
   - Quick action buttons

---

## Phase 5: Module Implementation

### Module 1 — User Management
- Login page (`/auth`) — email/password form
- Role-based access: admin sees everything, teachers see their classes/students, students see own attendance

### Module 2 — Student Management
- Table with search/filter
- Add student form (name, roll, class, DOB, gender, phone, address)
- Edit / delete
- View student profile with attendance history

### Module 3 — Teacher Management
- Table with search
- Add teacher form (name, employee_id, department, qualification, email, phone)
- Assign to classes/subjects

### Module 4 — Class & Subject Management
- CRUD for classes (name, section, year)
- Assign teachers + subjects to classes

### Module 5 — Attendance Management
- Select class → subject → date
- Mark attendance grid (student list with status toggle: Present/Absent/Late)
- Edit existing attendance records
- Student view: see own attendance calendar

### Module 6 — Reports
- Monthly attendance report per class
- Individual student report
- Attendance percentage statistics
- Exportable tables

---

## Phase 6: Polish

- Seed demo data (a few classes, students, teachers, sample attendance)
- Responsive layout
- Loading states and error handling
- Toast notifications (sonner)
- SEO metadata on all routes

---

## Sitemap & SEO
- Generate `sitemap.xml` and `robots.txt`
- Route-specific `head()` with titles/descriptions

---

## Acceptance Criteria
- [ ] Admin can log in with `admin`/`admin123`
- [ ] Admin can add/edit/delete students, teachers, classes
- [ ] Teacher can mark attendance for their assigned classes/subjects
- [ ] Student can view their own attendance history
- [ ] Dashboard shows attendance summary and charts
- [ ] Reports show monthly/yearly statistics
- [ ] All routes are protected by appropriate roles
- [ ] Responsive on mobile and desktop
