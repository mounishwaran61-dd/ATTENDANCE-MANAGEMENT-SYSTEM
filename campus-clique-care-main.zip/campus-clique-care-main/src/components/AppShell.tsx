import { type ReactNode, useEffect, useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, GraduationCap, ClipboardCheck, BarChart3,
  LogOut, Menu, X, GanttChartSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAMS, currentUser, logout } from "@/lib/ams-store";
import { Button } from "@/components/ui/button";

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["admin","staff","student"] as const },
  { to: "/students", label: "Students", icon: GraduationCap, roles: ["admin","staff"] as const },
  { to: "/staff", label: "Staff", icon: Users, roles: ["admin"] as const },
  { to: "/attendance", label: "Attendance", icon: ClipboardCheck, roles: ["admin","staff","student"] as const },
  { to: "/reports", label: "Reports", icon: BarChart3, roles: ["admin","staff"] as const },
];

export function AppShell({ children, title }: { children: ReactNode; title: string }) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(false);
  const session = useAMS((d) => d.session);

  useEffect(() => { setMounted(true); }, []);
  useEffect(() => {
    if (mounted && !session.userId) navigate({ to: "/login" });
  }, [mounted, session.userId, navigate]);

  if (!mounted) return null;
  const me = currentUser();
  if (!me) return null;

  const items = nav.filter((n) => (n.roles as readonly string[]).includes(me.role));

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-sidebar text-sidebar-foreground flex flex-col transition-transform lg:translate-x-0 lg:static",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="h-16 flex items-center gap-2 px-5 border-b border-sidebar-border">
          <div className="size-9 rounded-lg bg-primary-glow/20 grid place-items-center">
            <GanttChartSquare className="size-5 text-primary-glow" />
          </div>
          <div>
            <div className="text-sm font-semibold leading-tight">AMS</div>
            <div className="text-[11px] text-sidebar-foreground/60">College Attendance</div>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {items.map((it) => {
            const active = pathname === it.to || pathname.startsWith(it.to + "/");
            return (
              <Link
                key={it.to}
                to={it.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                )}
              >
                <it.icon className="size-4" />
                {it.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-3 px-2 py-2">
            <div className="size-9 rounded-full bg-primary-glow/20 grid place-items-center text-sm font-medium">
              {me.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{me.name}</div>
              <div className="text-[11px] text-sidebar-foreground/60 capitalize">{me.role}</div>
            </div>
            <button
              onClick={() => { logout(); navigate({ to: "/login" }); }}
              className="text-sidebar-foreground/70 hover:text-sidebar-foreground"
              aria-label="Sign out"
            >
              <LogOut className="size-4" />
            </button>
          </div>
        </div>
      </aside>

      {open && (
        <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={() => setOpen(false)} />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b bg-card flex items-center px-4 lg:px-8 gap-3 sticky top-0 z-20">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen((o) => !o)}>
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
          <h1 className="text-lg font-semibold tracking-tight">{title}</h1>
          <div className="ml-auto text-sm text-muted-foreground hidden sm:block">
            {new Date().toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-8 space-y-6">{children}</main>
      </div>
    </div>
  );
}
